﻿#!/system/bin/sh
# 1. 隐藏 nemuinit (防止被检测，同时防止它重置属性)
if [ -f /system/bin/nemuinit ]; then
    mount -o bind /dev/null /system/bin/nemuinit
fi

# 2. 隐藏模拟器应用数据目录
EMPTY_DIR=/data/adb/modules/hide_mumu_files/empty_dir
mkdir -p $EMPTY_DIR

for dir in com.mumu.store com.mumu.acc com.mumu.shared.sdk com.nemu.nlp com.nemu.oaidmanager; do
    TARGET="/data/data/$dir"
    if [ -d "$TARGET" ]; then
        mount -o bind $EMPTY_DIR "$TARGET"
    fi
done