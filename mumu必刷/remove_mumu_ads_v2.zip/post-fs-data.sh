﻿#!/system/bin/sh
# Empty files to replace APKs
EMPTY=/data/adb/modules/remove_mumu_ads_v2/empty.apk
touch $EMPTY

# Replace Game Center
mount -o bind $EMPTY /system/priv-app/com.mumu.store/com.mumu.store.apk

# Replace Account Service
mount -o bind $EMPTY /system/priv-app/com.mumu.acc/com.mumu.acc.apk

# Replace NLP
mount -o bind $EMPTY /system/priv-app/com.nemu.nlp/com.nemu.nlp.apk